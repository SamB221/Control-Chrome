The Chrome version of control

Allows you to turn off Reddit features, such as the main feed, 
subreddit feeds, notifications, and the trending page. 
